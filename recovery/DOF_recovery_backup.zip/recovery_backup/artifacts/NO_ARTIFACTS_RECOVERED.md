# ML Artifacts

No previously generated ML artifacts survived the sandbox recycling.

Lost in the fresh re-clone of `dof-repo` (reflog shows only the `clone` entry):
- `ml/` directory (trained models, datasets, metrics.json, real_models.py, pipelines, README)
- `work/` extracted dataset staging area
- edits to backend/ml-inference-service/{main.py,advanced_lstm_model.py} and tests/test_ml_inference_service.py
- helper scripts (recon_xlsx.py, git_askpass_gh.sh)

The 5 models must be retrained from the datasets in `datasets/` before any push to `parsa`.
